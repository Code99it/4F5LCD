#include "lcd.h"
#include "gpio.h"
#include "esp_rom_gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "hal/gpio_ll.h"
#include "soc/gpio_struct.h"
#include "soc/gpio_reg.h"
#include "esp_timer.h"
#include "font.h"
#include "color.h"
#include <math.h>
#include <stdint.h>
#include <stdbool.h>

#define GPIO_RS (1 << LCD_RS)
#define GPIO_WR (1 << LCD_WR)
#define GPIO_CS (1 << LCD_CS)

static const gpio_num_t lcd_data_pins[8] = {
    LCD_DATA_0, LCD_DATA_1, LCD_DATA_2, LCD_DATA_3,
    LCD_DATA_4, LCD_DATA_5, LCD_DATA_6, LCD_DATA_7
};

void lcd_gpio_write(gpio_num_t pin, bool level) {
    if (level)
        GPIO.out_w1ts = (1 << pin);
    else
        GPIO.out_w1tc = (1 << pin);
}

void lcd_init(void) {
    // Datenleitungen konfigurieren
    for (int i = 0; i < 8; i++) {
        gpio_reset_pin(lcd_data_pins[i]);
        gpio_set_direction(lcd_data_pins[i], GPIO_MODE_OUTPUT);
    }

    // Steuerleitungen konfigurieren
    gpio_reset_pin(LCD_RS);
    gpio_set_direction(LCD_RS, GPIO_MODE_OUTPUT);

    gpio_reset_pin(LCD_WR);
    gpio_set_direction(LCD_WR, GPIO_MODE_OUTPUT);

    gpio_reset_pin(LCD_CS);
    gpio_set_direction(LCD_CS, GPIO_MODE_OUTPUT);

    gpio_reset_pin(LCD_RST);
    gpio_set_direction(LCD_RST, GPIO_MODE_OUTPUT);

    // Optional: RD-Leitung, wenn verwendet
#if LCD_RD >= 0
    gpio_reset_pin(LCD_RD);
    gpio_set_direction(LCD_RD, GPIO_MODE_OUTPUT);
#endif

    // Initialzustände
    lcd_gpio_write(LCD_CS, LOW);
    lcd_gpio_write(LCD_WR, HIGH);
    lcd_gpio_write(LCD_RS, HIGH);
#if LCD_RD >= 0
    lcd_gpio_write(LCD_RD, HIGH);
#endif

    // Reset-Sequenz
    lcd_gpio_write(LCD_RST, LOW);
    vTaskDelay(pdMS_TO_TICKS(20));
    lcd_gpio_write(LCD_RST, HIGH);
    vTaskDelay(pdMS_TO_TICKS(150));
}

void lcd_driver_init(void) {
    vTaskDelay(pdMS_TO_TICKS(20));  // Power-on delay

    lcd_write_command(0x11); // Sleep OUT
    vTaskDelay(pdMS_TO_TICKS(120));

    lcd_write_command(0x3A); // Interface Pixel Format
    lcd_write_data(0x55);    // 16-bit/pixel (RGB565)

    lcd_write_command(0x36); // Memory Access Control (Rotation + BGR)
    lcd_write_data(0x48);    // MX=1, MY=0, MV=0, ML=0, BGR=1

    // Optional: Set Gamma Curve (can be omitted for basic test)
    lcd_write_command(0xF2);
    lcd_write_data(0x08);

    // Display ON
    lcd_write_command(0x29); // Display ON
    vTaskDelay(pdMS_TO_TICKS(20));
}

void lcd_write_bus(uint8_t value) {
    for (int i = 0; i < 8; i++) {
        lcd_gpio_write(lcd_data_pins[i], (value >> i) & 0x01);
    }
}

static void lcd_write_bus_fast(uint8_t value) {
    // Erst alle relevanten Bits auf 0 setzen (Clear)
    GPIO.out_w1tc = ((1 << 1) | (1 << 3) | (1 << 4) | (1 << 5) |
                     (1 << 6) | (1 << 7) | (1 << 15) | (1 << 16));

    // Dann neue Bits setzen
    uint32_t mapped = 0;
    mapped |= ((value >> 0) & 1) << 1;
    mapped |= ((value >> 1) & 1) << 3;
    mapped |= ((value >> 2) & 1) << 4;
    mapped |= ((value >> 3) & 1) << 5;
    mapped |= ((value >> 4) & 1) << 6;
    mapped |= ((value >> 5) & 1) << 7;
    mapped |= ((value >> 6) & 1) << 15;
    mapped |= ((value >> 7) & 1) << 16;

    GPIO.out_w1ts = mapped;
}

void lcd_write_command(uint8_t cmd) {
    GPIO.out_w1tc = GPIO_RS;     // RS = 0
    GPIO.out_w1tc = GPIO_WR;     // WR = 0
    lcd_write_bus_fast(cmd);
    GPIO.out_w1ts = GPIO_WR;     // WR = 1
}

void lcd_write_data(uint8_t data) {
    GPIO.out_w1ts = GPIO_RS;     // RS = 1
    GPIO.out_w1tc = GPIO_WR;     // WR = 0
    lcd_write_bus_fast(data);
    GPIO.out_w1ts = GPIO_WR;     // WR = 1
}

/**
 * @brief Wandelt eine 24-Bit-Hexfarbe (0xRRGGBB) in RGB565 (16 Bit) um.
 * 
 * @param hex_color 24-Bit-Farbwert (z. B. 0xFFAA33)
 * @return RGB565-Farbwert (z. B. 0bRRRRRGGGGGGBBBBB)
 */
uint16_t hex_to_rgb565(uint32_t hex_color) {
    uint8_t r = (hex_color >> 16) & 0xFF;
    uint8_t g = (hex_color >> 8) & 0xFF;
    uint8_t b = hex_color & 0xFF;

    uint16_t r5 = (r * 31) / 255;
    uint16_t g6 = (g * 63) / 255;
    uint16_t b5 = (b * 31) / 255;

    return (r5 << 11) | (g6 << 5) | b5;
}

void lcd_set_address_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
    // Column address set (X)
    lcd_write_command(0x2A);
    lcd_write_data(x0 >> 8);
    lcd_write_data(x0 & 0xFF);
    lcd_write_data(x1 >> 8);
    lcd_write_data(x1 & 0xFF);

    // Page address set (Y)
    lcd_write_command(0x2B);
    lcd_write_data(y0 >> 8);
    lcd_write_data(y0 & 0xFF);
    lcd_write_data(y1 >> 8);
    lcd_write_data(y1 & 0xFF);

    // Memory Write
    lcd_write_command(0x2C);
}

void lcd_fill_color(uint16_t color) {
    const uint16_t width = 320;
    const uint16_t height = 480;
    const uint32_t total_pixels = width * height;

    lcd_set_address_window(0, 0, width - 1, height - 1);

    uint8_t high = color >> 8;
    uint8_t low = color & 0xFF;

    for (uint32_t i = 0; i < total_pixels; i++) {
        lcd_write_data(high);
        lcd_write_data(low);
    }
}

void lcd_fill_rect(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color) {
    // Bereich setzen
    lcd_set_address_window(x0, y0, x1, y1);

    uint32_t total_pixels = (x1 - x0 + 1) * (y1 - y0 + 1);
    uint8_t high = color >> 8;
    uint8_t low = color & 0xFF;

    for (uint32_t i = 0; i < total_pixels; i++) {
        lcd_write_data(high);
        lcd_write_data(low);
    }
}

void lcd_fill_rainbow(void) {
    const uint16_t band_height = LCD_PIXEL_HEIGHT / 10;

    lcd_fill_rect(0, 0 * band_height, LCD_PIXEL_WIDTH - 1, 1 * band_height - 1, hex_to_rgb565(0xFF0000)); // Rot
    vTaskDelay(1);
    lcd_fill_rect(0, 1 * band_height, LCD_PIXEL_WIDTH - 1, 2 * band_height - 1, hex_to_rgb565(0xFF7F00)); // Orange
    vTaskDelay(1);
    lcd_fill_rect(0, 2 * band_height, LCD_PIXEL_WIDTH - 1, 3 * band_height - 1, hex_to_rgb565(0xFFFF00)); // Gelb
    vTaskDelay(1);
    lcd_fill_rect(0, 3 * band_height, LCD_PIXEL_WIDTH - 1, 4 * band_height - 1, hex_to_rgb565(0x00FF00)); // Grün
    vTaskDelay(1);
    lcd_fill_rect(0, 4 * band_height, LCD_PIXEL_WIDTH - 1, 5 * band_height - 1, hex_to_rgb565(0x00FFFF)); // Türkis
    vTaskDelay(1);
    lcd_fill_rect(0, 5 * band_height, LCD_PIXEL_WIDTH - 1, 6 * band_height - 1, hex_to_rgb565(0x0000FF)); // Blau
    vTaskDelay(1);
    lcd_fill_rect(0, 6 * band_height, LCD_PIXEL_WIDTH - 1, 7 * band_height - 1, hex_to_rgb565(0x4B0082)); // Indigo
    vTaskDelay(1);
    lcd_fill_rect(0, 7 * band_height, LCD_PIXEL_WIDTH - 1, 8 * band_height - 1, hex_to_rgb565(0x8F00FF)); // Violett
    vTaskDelay(1);
    lcd_fill_rect(0, 8 * band_height, LCD_PIXEL_WIDTH - 1, 9 * band_height - 1, hex_to_rgb565(0xFF69B4)); // Rosa
    vTaskDelay(1);
    lcd_fill_rect(0, 9 * band_height, LCD_PIXEL_WIDTH - 1, LCD_PIXEL_HEIGHT - 1, hex_to_rgb565(0xFFFFFF)); // Weiß
    vTaskDelay(1);
}

void lcd_test_fill_fps(void)
{
    const int test_frames = 10;
    int64_t start_time = esp_timer_get_time();  // in µs

    for (int i = 0; i < test_frames; i++) {
        // Wechselfarbe (optional, damit Display nicht cached)
        uint16_t color = (i % 2 == 0) ? hex_to_rgb565(0x0000FF) : hex_to_rgb565(0x00FF00);
        lcd_fill_color(color);
    }

    int64_t end_time = esp_timer_get_time();  // in µs
    int64_t elapsed_us = end_time - start_time;

    float elapsed_s = elapsed_us / 1000000.0f;
    float fps = test_frames / elapsed_s;

    printf("Elapsed time: %.2f s for %d frames\n", elapsed_s, test_frames);
    printf("FPS: %.2f\n", fps);
}


/**
 * Zeichnet ein einzelnes Zeichen anhand des ASCII-Codes.
 *
 * @param c Das Zeichen (z.B. 'Q')
 * @param x Startposition X
 * @param y Startposition Y
 *
 * @return neue Cursor-X-Position (x + Zeichenbreite)
 */
uint16_t lcd_draw_char(char c, uint16_t x, uint16_t y, uint8_t px) {
    const FontGlyph *glyph;

    switch (px) {
        case 13:
            glyph = &outfit13_glyphs[(uint8_t)c];
            break;
        case 29:
            glyph = &outfit29_glyphs[(uint8_t)c];
            break;
        case 36:
            glyph = &outfit36_glyphs[(uint8_t)c];
            break;
        default:
            return x; // unbekannte Größe – Zeichen überspringen
    }

    if (!glyph->data) {
        return x; // unbekanntes Zeichen – überspringen
    }

    lcd_set_address_window(x, y, x + glyph->width - 1, y + glyph->height - 1);

    for (uint32_t i = 0; i < glyph->width * glyph->height; i++) {
        uint16_t brightness = glyph->data[i]; // z. B. 0x0000–0xFFFF
        uint16_t modulated = scale_color_rgb565(hex_to_rgb565(0x00AAFF), brightness);
        lcd_write_data(modulated >> 8);
        lcd_write_data(modulated & 0xFF);
    }

    return x + glyph->width;
}

uint16_t scale_color_rgb565(uint16_t base_color, uint16_t brightness) {
    uint8_t r = (base_color >> 11) & 0x1F;
    uint8_t g = (base_color >> 5) & 0x3F;
    uint8_t b = base_color & 0x1F;

    r = (r * brightness) >> 16;
    g = (g * brightness) >> 16;
    b = (b * brightness) >> 16;

    return (r << 11) | (g << 5) | b;
}

/**
 * Zeichnet ein Zeichen in Farbe mit Anti-Aliasing.
 *
 * @param c        Das Zeichen (z. B. 'Q')
 * @param x        Startposition X
 * @param y        Startposition Y
 * @param px       Schriftgröße (z. B. 29 oder 36)
 * @param hex_rgb  Wunschfarbe im Format 0xRRGGBB
 *
 * @return neue Cursor-X-Position (x + Zeichenbreite)
 */
uint16_t lcd_draw_colored_char(char c, uint16_t x, uint16_t y, uint8_t px, uint32_t hex_rgb) {
    const FontGlyph *glyph;
    switch (px) {
        case 13:
            glyph = &outfit13_glyphs[(uint8_t)c];
            break;
        case 24:
            glyph = &outfit24_glyphs[(uint8_t)c];
            break;
        case 29:
            glyph = &outfit29_glyphs[(uint8_t)c];
            break;
        case 36:
            glyph = &outfit36_glyphs[(uint8_t)c];
            break;
        default:
            return x;
    }

    if (!glyph || !glyph->data)
        return x;

    uint16_t base_color = hex_to_rgb565(hex_rgb);
    lcd_set_address_window(x, y, x + glyph->width - 1, y + glyph->height - 1);

    for (uint32_t i = 0; i < glyph->width * glyph->height; i++) {
        uint16_t brightness = glyph->data[i];  // Originale Graustufe
        uint16_t modulated = scale_color_rgb565(base_color, brightness);
        lcd_write_data(modulated >> 8);
        lcd_write_data(modulated & 0xFF);
    }

    return x + glyph->width + FONT_LETTER_SPACING_PX;
}

uint16_t lcd_draw_string(const char *str, uint16_t x, uint16_t y, uint8_t px) {
    while (*str) {
        x = lcd_draw_char(*str, x, y, px);
        str++;
    }
    return x; // neue Cursor-Position nach dem String
}

uint16_t lcd_draw_colored_string(const char *str, uint16_t x, uint16_t y, uint8_t px, uint32_t hex_rgb) {
    while (*str) {
        x = lcd_draw_colored_char(*str, x, y, px, hex_rgb);
        str++;
    }
    return x;  // Neue Cursor-Position nach dem String
}

/**
 * Zeichnet einen zentrierten, farbigen String mit Anti-Aliasing.
 *
 * @param str      Der String (z.B. "Hallo Welt")
 * @param x_center Die horizontale Mitte, um die zentriert wird
 * @param y        Y-Koordinate des Textes
 * @param px       Schriftgröße (29 oder 36)
 * @param hex_rgb  Farbe in 0xRRGGBB
 */
uint16_t lcd_draw_colored_string_centered(const char *str, uint16_t x_center, uint16_t y, uint8_t px, uint32_t hex_rgb) {
    const FontGlyph *glyph;
    uint16_t total_width = 0;
    const char *ptr = str;

    while (*ptr) {
        switch (px) {
            case 13:
                glyph = &outfit13_glyphs[(uint8_t)*ptr];
                break;
            case 29:
                glyph = &outfit29_glyphs[(uint8_t)*ptr];
                break;
            case 36:
                glyph = &outfit36_glyphs[(uint8_t)*ptr];
                break;
            case 24:
                glyph = &outfit24_glyphs[(uint8_t)*ptr];
                break;
            default:
                glyph = NULL;
                break;
        }

        if (glyph && glyph->data) {
            total_width += glyph->width + FONT_LETTER_SPACING_PX;
        }

        ptr++;
    }

    if (total_width > 0) {
        total_width -= FONT_LETTER_SPACING_PX;  // Letztes Spacing entfernen
    }

    int16_t start_x = x_center - total_width / 2;
    if (start_x < 0) start_x = 0;

    return lcd_draw_colored_string(str, (uint16_t)start_x, y, px, hex_rgb);
}


/**
 * Zeichnet eine horizontale Linie auf dem Display.
 *
 * @param y         Y-Koordinate (Oberkante der Linie)
 * @param width     Breite in Pixel (0 = volle Displaybreite)
 * @param thickness Dicke der Linie (Höhe in Pixeln)
 * @param color     RGB565-Farbe
 */
void lcd_draw_horizontal_line(uint16_t y, uint16_t width, uint16_t thickness, uint16_t color) {
    if (width == 0) {
        width = LCD_PIXEL_WIDTH;  // z. B. 320
    }

    uint16_t x0 = 0;
    uint16_t x1 = x0 + width - 1;
    uint16_t y0 = y;
    uint16_t y1 = y + thickness - 1;

    lcd_set_address_window(x0, y0, x1, y1);

    uint8_t high = color >> 8;
    uint8_t low = color & 0xFF;
    uint32_t total_pixels = width * thickness;

    for (uint32_t i = 0; i < total_pixels; i++) {
        lcd_write_data(high);
        lcd_write_data(low);
    }
}

/**
 * Misst die FPS beim Füllen eines bestimmten Bildschirmbereichs.
 *
 * @param x0 Linke X-Koordinate
 * @param y0 Obere Y-Koordinate
 * @param x1 Rechte X-Koordinate
 * @param y1 Untere Y-Koordinate
 * @param frames Anzahl Testdurchläufe
 */
void lcd_test_fill_area_fps(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t frames) {
    int64_t start_time = esp_timer_get_time();  // µs

    for (int i = 0; i < frames; i++) {
        uint32_t color = (i % 2 == 0) ? 0x0000FF : 0x00FF00;
        lcd_fill_rect(x0, y0, x1, y1, hex_to_rgb565(color));
    }

    int64_t end_time = esp_timer_get_time();
    int64_t elapsed_us = end_time - start_time;

    float elapsed_s = elapsed_us / 1000000.0f;
    float fps = frames / elapsed_s;

    printf("Filled area (%u,%u)-(%u,%u) for %u frames\n", x0, y0, x1, y1, frames);
    printf("Elapsed time: %.2f s, FPS: %.2f\n", elapsed_s, fps);
}


// Mischfunktion für RGB565
uint16_t blend_rgb565(uint16_t fg, uint16_t bg, uint8_t alpha) {
    uint8_t fg_r = (fg >> 11) & 0x1F;
    uint8_t fg_g = (fg >> 5) & 0x3F;
    uint8_t fg_b = fg & 0x1F;

    uint8_t bg_r = (bg >> 11) & 0x1F;
    uint8_t bg_g = (bg >> 5) & 0x3F;
    uint8_t bg_b = bg & 0x1F;

    uint8_t r = (fg_r * alpha + bg_r * (255 - alpha)) / 255;
    uint8_t g = (fg_g * alpha + bg_g * (255 - alpha)) / 255;
    uint8_t b = (fg_b * alpha + bg_b * (255 - alpha)) / 255;

    return (r << 11) | (g << 5) | b;
}

void lcd_draw_menu_select_point(
    uint16_t *fb,
    uint16_t fb_width,
    uint16_t fb_height,
    uint16_t x_offset,
    uint16_t y_offset,
    uint16_t ring_diameter,
    uint16_t ring_thickness,
    uint16_t center_diameter,
    uint32_t hex_ring_color,
    uint32_t hex_center_color,
    uint32_t hex_line_color,
    uint16_t line_length,
    uint16_t line_thickness,
    uint32_t hex_background_color
) {
    const float center_shift = 0.25f; // Nur der innere Kreis leicht nach links
    const float outer_radius = ring_diameter / 2.0f;
    const float inner_radius = outer_radius - ring_thickness;
    const float center_radius = center_diameter / 2.0f;

    const float center_x = x_offset + outer_radius;
    const float center_y = y_offset + outer_radius;

    uint16_t ring_color = hex_to_rgb565(hex_ring_color);
    uint16_t center_color = hex_to_rgb565(hex_center_color);
    uint16_t line_color = hex_to_rgb565(hex_line_color);
    uint16_t bg_color = hex_to_rgb565(hex_background_color);

    for (int y = 0; y < fb_height; y++) {
        for (int x = 0; x < fb_width; x++) {
            float dx = (float)x - center_x;
            float dy = (float)y - center_y;
            float dist = sqrtf(dx * dx + dy * dy);

            int index = y * fb_width + x;

            if (dist <= outer_radius && dist >= inner_radius) {
                float alpha = 1.0f;
                if (dist > outer_radius - 1.0f) {
                    alpha = outer_radius - dist;
                } else if (dist < inner_radius + 1.0f) {
                    alpha = dist - inner_radius;
                }
                alpha = fminf(fmaxf(alpha, 0.0f), 1.0f);

                uint32_t r = ((ring_color >> 11) & 0x1F) * alpha + ((bg_color >> 11) & 0x1F) * (1 - alpha);
                uint32_t g = ((ring_color >> 5) & 0x3F) * alpha + ((bg_color >> 5) & 0x3F) * (1 - alpha);
                uint32_t b = (ring_color & 0x1F) * alpha + (bg_color & 0x1F) * (1 - alpha);
                fb[index] = (r << 11) | (g << 5) | b;

            } else if (sqrtf((x - (center_x - center_shift)) * (x - (center_x - center_shift)) + dy * dy) < center_radius) {
                float dist_inner = sqrtf((x - (center_x - center_shift)) * (x - (center_x - center_shift)) + dy * dy);
                float alpha = fminf(1.0f, center_radius - dist_inner);
                alpha = fminf(fmaxf(alpha, 0.0f), 1.0f);

                uint32_t r = ((center_color >> 11) & 0x1F) * alpha + ((bg_color >> 11) & 0x1F) * (1 - alpha);
                uint32_t g = ((center_color >> 5) & 0x3F) * alpha + ((bg_color >> 5) & 0x3F) * (1 - alpha);
                uint32_t b = (center_color & 0x1F) * alpha + (bg_color & 0x1F) * (1 - alpha);
                fb[index] = (r << 11) | (g << 5) | b;

            } else {
                fb[index] = bg_color;
            }
        }
    }

    // Linie rechts andocken, bleibt an originaler Position
    int line_start_x = x_offset + ring_diameter - 1;
    int line_start_y = (int)(center_y - line_thickness / 2);

    for (int y = 0; y < line_thickness; y++) {
        for (int x = 0; x < line_length; x++) {
            int px = line_start_x + x;
            int py = line_start_y + y;
            if (px >= 0 && px < fb_width && py >= 0 && py < fb_height) {
                fb[py * fb_width + px] = line_color;
            }
        }
    }
}





void lcd_fill_framebuffer(uint16_t *fb, uint16_t fb_width, uint16_t fb_height, uint32_t hex_color) {
    uint16_t color = hex_to_rgb565(hex_color);
    for (int i = 0; i < fb_width * fb_height; ++i) {
        fb[i] = color;
    }
}




void lcd_blit_framebuffer(
    uint16_t *fb,
    uint16_t fb_width,
    uint16_t fb_height,
    uint16_t target_x,
    uint16_t target_y
) {
    lcd_set_address_window(target_x, target_y, target_x + fb_width - 1, target_y + fb_height - 1);
    for (int y = 0; y < fb_height; y++) {
        for (int x = 0; x < fb_width; x++) {
            uint16_t color = fb[y * fb_width + x];
            lcd_write_data(color >> 8);
            lcd_write_data(color & 0xFF);
        }
    }
}

/*void lcd_draw_menu_select_point(
    uint16_t *fb,
    uint16_t y_offset,
    uint16_t outer_radius,
    uint16_t ring_thickness,
    uint32_t hex_ring_color,
    uint32_t hex_center_color,
    uint16_t center_gap,
    uint32_t hex_line_color,
    uint16_t line_length
) {
    const uint16_t cx = FB_WIDTH / 2;
    const uint16_t cy = y_offset + outer_radius;
    const uint16_t inner_radius = outer_radius - ring_thickness;
    const uint16_t center_radius = inner_radius - center_gap;

    const uint16_t col_ring   = hex_to_rgb565(hex_ring_color);
    const uint16_t col_center = hex_to_rgb565(hex_center_color);
    const uint16_t col_line   = hex_to_rgb565(hex_line_color);

    // Ring mit einfacher Kantenweichzeichnung (AA light)
    for (int16_t y = -outer_radius; y <= outer_radius; ++y) {
        for (int16_t x = -outer_radius; x <= outer_radius; ++x) {
            float dist = sqrtf(x * x + y * y);
            if (dist >= inner_radius && dist <= outer_radius) {
                int px = cx + x;
                int py = cy + y;
                if (px >= 0 && px < FB_WIDTH && py >= 0 && py < FB_HEIGHT) {
                    fb[py * FB_WIDTH + px] = col_ring;
                }
            }
        }
    }

    // Innenkreis füllen
    for (int16_t y = -center_radius; y <= center_radius; ++y) {
        for (int16_t x = -center_radius; x <= center_radius; ++x) {
            if (x * x + y * y <= center_radius * center_radius) {
                int px = cx + x;
                int py = cy + y;
                if (px >= 0 && px < FB_WIDTH && py >= 0 && py < FB_HEIGHT) {
                    fb[py * FB_WIDTH + px] = col_center;
                }
            }
        }
    }

    // Linie rechts vom Kreis
    int line_y = cy;
    int line_x0 = cx + outer_radius;
    for (int i = 0; i < line_length; ++i) {
        int px = line_x0 + i;
        if (px >= 0 && px < FB_WIDTH && line_y >= 0 && line_y < FB_HEIGHT) {
            fb[line_y * FB_WIDTH + px] = col_line;
        }
    }
}*/

uint16_t lcd_draw_colored_string_to_frmbuf(
    uint16_t *fb,
    uint16_t fb_width,
    const char *str,
    uint16_t x,
    uint16_t y,
    uint8_t px,
    uint32_t hex_rgb
) {
    const FontGlyph *glyph;
    uint16_t base_color = hex_to_rgb565(hex_rgb);

    while (*str) {
        char c = *str;
        switch (px) {
            case 13:
                glyph = &outfit13_glyphs[(uint8_t)c];
                break;
            case 24:
                glyph = &outfit24_glyphs[(uint8_t)c];
                break;
            case 29:
                glyph = &outfit29_glyphs[(uint8_t)c];
                break;
            case 36:
                glyph = &outfit36_glyphs[(uint8_t)c];
                break;
            default:
                return x;
        }

        if (glyph && glyph->data) {
            for (uint16_t row = 0; row < glyph->height; row++) {
                for (uint16_t col = 0; col < glyph->width; col++) {
                    uint16_t brightness = glyph->data[row * glyph->width + col];
                    uint16_t color = scale_color_rgb565(base_color, brightness);

                    uint16_t px_x = x + col;
                    uint16_t px_y = y + row;
                    if (px_x < fb_width) { // einfache Bounds-Prüfung
                        fb[px_y * fb_width + px_x] = color;
                    }
                }
            }
            x += glyph->width + FONT_LETTER_SPACING_PX;
        }

        str++;
    }

    return x; // neue Cursor-Position nach dem String
}

void lcd_draw_framebuffer(uint16_t *buffer, uint16_t width, uint16_t height, uint16_t x, uint16_t y) {
    lcd_set_address_window(x, y, x + width - 1, y + height - 1);
    for (uint32_t i = 0; i < width * height; i++) {
        lcd_write_data(buffer[i] >> 8);       // High-Byte
        lcd_write_data(buffer[i] & 0xFF);     // Low-Byte
    }
}

void lcd_draw_framebuffer_region(uint16_t *fb, int fb_width, int x_offset, int y_offset, int width, int height, int lcd_x, int lcd_y) {
    lcd_set_address_window(lcd_x, lcd_y, lcd_x + width - 1, lcd_y + height - 1);

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            uint16_t pixel = fb[(y_offset + y) * fb_width + (x_offset + x)];
            lcd_write_data(pixel >> 8);
            lcd_write_data(pixel & 0xFF);
        }
    }
}

uint16_t lcd_draw_colored_string_centered_at_x_to_frmbuf(
    uint16_t *fb,              // Framebuffer-Pointer
    uint16_t fb_width,         // Framebuffer-Breite in Pixeln
    const char *str,           // Textstring
    uint16_t center_x,         // Mittelpunkt für horizontale Zentrierung
    uint16_t y,                // Y-Position im Framebuffer
    uint8_t px,                // Schriftgröße in px
    uint32_t hex_rgb           // RGB-Farbe in 0xRRGGBB
) {
    // Breite des gesamten Strings berechnen
    uint16_t str_width = 0;
    const FontGlyph *glyph;

    for (const char *p = str; *p; p++) {
        switch (px) {
            case 13:
                glyph = &outfit13_glyphs[(uint8_t)(*p)];
                break;
            case 24:
                glyph = &outfit24_glyphs[(uint8_t)(*p)];
                break;
            case 29:
                glyph = &outfit29_glyphs[(uint8_t)(*p)];
                break;
            case 36:
                glyph = &outfit36_glyphs[(uint8_t)(*p)];
                break;
            default:
                return center_x;
        }

        if (glyph && glyph->data)
            str_width += glyph->width + FONT_LETTER_SPACING_PX;
    }

    if (str_width > fb_width) {
        // Zu breit, abbrechen
        return center_x;
    }

    // Linker Startpunkt für zentrierten Text um center_x
    uint16_t start_x = (center_x > str_width / 2) ? (center_x - str_width / 2) : 0;

    return lcd_draw_colored_string_to_frmbuf(fb, fb_width, str, start_x, y, px, hex_rgb);
}

uint16_t blend_rgb565_with_black(uint16_t color, float factor) {
    uint8_t r = (color >> 11) & 0x1F;
    uint8_t g = (color >> 5) & 0x3F;
    uint8_t b = color & 0x1F;

    r = (uint8_t)(r * factor);
    g = (uint8_t)(g * factor);
    b = (uint8_t)(b * factor);

    return (r << 11) | (g << 5) | b;
}

void draw_circle_quarter_aa(int cx, int cy, int r, uint16_t color, uint8_t quadrant_mask) {
    int x = 0, y = r;
    int d = 3 - 2 * r;

    while (x <= y) {
        // Diese 8 Punkte werden optional gezeichnet – je nach Quadrant
        struct { int dx, dy; uint8_t mask; } pts[] = {
            {-x, -y, 0b0001}, {-y, -x, 0b0001},  // oben links
            { x, -y, 0b0010}, { y, -x, 0b0010},  // oben rechts
            {-x,  y, 0b0100}, {-y,  x, 0b0100},  // unten links
            { x,  y, 0b1000}, { y,  x, 0b1000}   // unten rechts
        };

        for (int i = 0; i < 8; i++) {
            if (quadrant_mask & pts[i].mask) {
                int px = cx + pts[i].dx;
                int py = cy + pts[i].dy;

                // Approx. Abstand zur echten Kreislinie
                float dist = fabsf(sqrtf((float)(pts[i].dx * pts[i].dx + pts[i].dy * pts[i].dy)) - (float)r);

                // Maximaldistanz für AA-Effekt (z. B. 1.5 Pixel)
                float max_dist = 1.5f;
                float intensity = fmaxf(0.0f, 1.0f - (dist / max_dist));

                uint16_t blended = blend_rgb565_with_black(color, intensity);
                lcd_draw_pixel(px, py, blended);
            }
        }

        if (d < 0) {
            d += 4 * x + 6;
        } else {
            d += 4 * (x - y) + 10;
            y--;
        }
        x++;
    }
}


void draw_rounded_rect(
    int x0, int y0, int x1, int y1,
    int radius, int thickness, uint16_t color
) {
    // Linien oben/unten
    for (int t = 0; t < thickness; t++) {
        lcd_draw_hline(x0 + radius, x1 - radius, y0 + t, color);            // oben
        lcd_draw_hline(x0 + radius, x1 - radius, y1 - 1 - t, color);        // unten
    }

    // Linien links/rechts
    for (int t = 0; t < thickness; t++) {
        lcd_draw_vline(x0 + t, y0 + radius, y1 - radius, color);            // links
        lcd_draw_vline(x1 - 1 - t, y0 + radius, y1 - radius, color);        // rechts
    }

    // Ecken zeichnen
    for (int t = 0; t < thickness; t++) {
        draw_circle_quarter_aa(x0 + radius, y0 + radius, radius - t, color, 0b0001); // oben links
        draw_circle_quarter_aa(x1 - radius - 1, y0 + radius, radius - t, color, 0b0010); // oben rechts
        draw_circle_quarter_aa(x0 + radius, y1 - radius - 1, radius - t, color, 0b0100); // unten links
        draw_circle_quarter_aa(x1 - radius - 1, y1 - radius - 1, radius - t, color, 0b1000); // unten rechts
    }
}


void lcd_draw_centered_rounded_frame(
    const char *text,
    uint16_t center_x,
    uint16_t top_y,
    uint8_t px,
    uint8_t padding,
    uint8_t border_thickness,
    uint8_t corner_radius,
    uint32_t border_color_hex
) {
    const FontGlyph *glyphs = NULL;
    uint8_t height = 0;

    switch (px) {
        case 13: glyphs = outfit13_glyphs; height = outfit13_glyphs['A'].height; break;
        case 24: glyphs = outfit24_glyphs; height = outfit24_glyphs['A'].height; break;
        case 29: glyphs = outfit29_glyphs; height = outfit29_glyphs['A'].height; break;
        case 36: glyphs = outfit36_glyphs; height = outfit36_glyphs['A'].height; break;
        default: return;
    }

    uint16_t total_width = 0;
    for (const char *p = text; *p; p++) {
        total_width += glyphs[(uint8_t)*p].width + FONT_LETTER_SPACING_PX;
    }
    if (total_width > 0) total_width -= FONT_LETTER_SPACING_PX;

    int16_t x0 = center_x - (total_width / 2) - (padding * 2);  // links: 2x horizontaler Padding
    int16_t x1 = center_x + (total_width / 2) + (padding * 2);  // rechts: 2x horizontaler Padding
    int16_t y0 = top_y - padding;                               // oben: 1x vertikaler Padding
    int16_t y1 = top_y + height + padding;                      // unten: 1x vertikaler Padding

    uint16_t border_color = hex_to_rgb565(border_color_hex);

    draw_rounded_rect(x0, y0, x1, y1, corner_radius, border_thickness, border_color);
}

void lcd_draw_pixel(uint16_t x, uint16_t y, uint16_t color) {
    lcd_set_address_window(x, y, x, y);
    lcd_write_data(color >> 8);
    lcd_write_data(color & 0xFF);
}

void lcd_draw_hline(uint16_t x0, uint16_t x1, uint16_t y, uint16_t color) {
    if (x1 < x0) { uint16_t tmp = x0; x0 = x1; x1 = tmp; }
    lcd_set_address_window(x0, y, x1, y);
    for (uint16_t x = x0; x <= x1; x++) {
        lcd_write_data(color >> 8);
        lcd_write_data(color & 0xFF);
    }
}

void lcd_draw_vline(uint16_t x, uint16_t y0, uint16_t y1, uint16_t color) {
    if (y1 < y0) { uint16_t tmp = y0; y0 = y1; y1 = tmp; }
    lcd_set_address_window(x, y0, x, y1);
    for (uint16_t y = y0; y <= y1; y++) {
        lcd_write_data(color >> 8);
        lcd_write_data(color & 0xFF);
    }
}


void lcd_delete_centered_rounded_frame(
    const char *text,
    uint16_t center_x,
    uint16_t top_y,
    uint8_t px,
    uint8_t padding,
    uint8_t border_thickness,
    uint8_t corner_radius,
    uint32_t background_color_hex
) {
    const FontGlyph *glyphs = NULL;
    uint8_t height = 0;

    switch (px) {
        case 13: glyphs = outfit13_glyphs; height = outfit13_glyphs['A'].height; break;
        case 24: glyphs = outfit24_glyphs; height = outfit24_glyphs['A'].height; break;
        case 29: glyphs = outfit29_glyphs; height = outfit29_glyphs['A'].height; break;
        case 36: glyphs = outfit36_glyphs; height = outfit36_glyphs['A'].height; break;
        default: return;
    }

    uint16_t total_width = 0;
    for (const char *p = text; *p; p++) {
        total_width += glyphs[(uint8_t)*p].width + FONT_LETTER_SPACING_PX;
    }
    if (total_width > 0) total_width -= FONT_LETTER_SPACING_PX;

    uint8_t padding_x = padding * 2;

    // Außenrahmen-Koordinaten (+1 px extra für Anti-Aliasing)
    int16_t outer_x0 = center_x - (total_width / 2) - padding_x - 1;
    int16_t outer_x1 = center_x + (total_width / 2) + padding_x + 1;
    int16_t outer_y0 = top_y - padding - 1;
    int16_t outer_y1 = top_y + height + padding + 1;

    // Innenrahmen-Koordinaten (keinen Text übermalen!)
    int16_t inner_x0 = center_x - (total_width / 2) - padding_x + border_thickness;
    int16_t inner_x1 = center_x + (total_width / 2) + padding_x - border_thickness;
    int16_t inner_y0 = top_y - padding + border_thickness;
    int16_t inner_y1 = top_y + height + padding - border_thickness;

    uint16_t bg = hex_to_rgb565(background_color_hex);

    // Oben
    lcd_fill_rect(outer_x0, outer_y0, outer_x1, inner_y0, bg);
    // Unten
    lcd_fill_rect(outer_x0, inner_y1, outer_x1, outer_y1, bg);
    // Links
    lcd_fill_rect(outer_x0, inner_y0, inner_x0, inner_y1, bg);
    // Rechts
    lcd_fill_rect(inner_x1, inner_y0, outer_x1, inner_y1, bg);
}

